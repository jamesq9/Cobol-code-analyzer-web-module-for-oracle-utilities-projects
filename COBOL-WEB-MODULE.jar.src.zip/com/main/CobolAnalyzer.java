/*     */ package com.main;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CobolAnalyzer
/*     */ {
/*  18 */   static final String[] COBOL_KEYWORDS = new String[] { "ACCEPT", "ACCESS", "ADD", "ADDRESS", "ADVANCING", "AFTER", "ALL", "ALPHABET", "ALPHABETIC", "ALPHABETIC-LOWER", "ALPHABETIC-UPPER", "ALPHANUMERIC", "ALPHANUMERIC-EDITED", "ALSO", "ALTER", "ALTERNATE", "AND", "ANY", "APPLY", "ARE", "AREA", "AREAS", "ASCENDING", "ASSIGN", "AT", "AUTHOR", "BASIS", "BEFORE", "BEGINNING", "BINARY", "BLANK", "BLOCK", "BOTTOM", "BY", "CALL", "CANCEL", "CBL", "CD", "CF", "CH", "CHARACTER", "CHARACTERS", "CLASS", "CLASS-ID", "CLOCK-UNITS", "CLOSE", "COBOL", "CODE", "CODE-SET", "COLLATING", "COLUMN", "COM-REG", "COMMA", "COMMON", "COMMUNICATION", "COMP", "COMP-1", "COMP-2", "COMP-3", "COMP-4", "COMP-5", "COMPUTATIONAL", "COMPUTATIONAL-1", "COMPUTATIONAL-2", "COMPUTATIONAL-3", "COMPUTATIONAL-4", "COMPUTATIONAL-5", "COMPUTE", "CONFIGURATION", "CONTAINS", "CONTENT", "CONTINUE", "CONTROL", "CONTROLS", "CONVERTING", "COPY", "CORR", "CORRESPONDING", "COUNT", "CURRENCY", "DATA", "DATE-COMPILED", "DATE-WRITTEN", "DAY", "DAY-OF-WEEK", "DBCS", "DE", "DEBUG-CONTENTS", "DEBUG-ITEM", "DEBUG-LINE", "DEBUG-NAME", "DEBUG-SUB-1", "DEBUG-SUB-2", "DEBUG-SUB-3", "DEBUGGING", "DECIMAL-POINT", "DECLARATIVES", "DELETE", "DELIMITED", "DELIMITER", "DEPENDING", "DESCENDING", "DESTINATION", "DETAIL", "DISPLAY", "DISPLAY-1", "DIVIDE", "DIVISION", "DOWN", "DUPLICATES", "DYNAMIC", "EGCS", "EGI", "EJECT", "ELSE", "EMI", "ENABLE", "END", "END-ADD", "END-CALL", "END-COMPUTE", "END-DELETE", "END-DIVIDE", "END-EVALUATE", "END-IF", "END-INVOKE", "END-MULTIPLY", "END-OF-PAGE", "END-PERFORM", "END-READ", "END-RECEIVE", "END-RETURN", "END-REWRITE", "END-SEARCH", "END-START", "END-STRING", "END-SUBTRACT", "END-UNSTRING", "END-WRITE", "ENDING", "ENTER", "ENTRY", "ENVIRONMENT", "EOP", "EQUAL", "ERROR", "ESI", "EVALUATE", "EVERY", "EXCEPTION", "EXIT", "EXTEND", "EXTERNAL", "FALSE", "FD", "FILE", "FILE-CONTROL", "FILLER", "FINAL", "FIRST", "FOOTING", "FOR", "FROM", "FUNCTION", "GENERATE", "GIVING", "GLOBAL", "GO", "GOBACK", "GREATER", "GROUP", "HEADING", "HIGH-VALUE", "HIGH-VALUES", "I-O", "I-O-CONTROL", "ID", "IDENTIFICATION", "IF", "IN", "INDEX", "INDEXED", "INDICATE", "INHERITS", "INITIAL", "INITIALIZE", "INITIATE", "INPUT", "INPUT-OUTPUT", "INSERT", "INSPECT", "INSTALLATION", "INTO", "INVALID", "INVOKE", "IS", "JUST", "JUSTIFIED", "KANJI", "KEY", "LABEL", "LAST", "LEADING", "LEFT", "LENGTH", "LESS", "LIMIT", "LIMITS", "LINAGE", "LINAGE-COUNTER", "LINE", "LINE-COUNTER", "LINES", "LINKAGE", "LOCAL-STORAGE", "LOCK", "LOW-VALUE", "LOW-VALUES", "MEMORY", "MERGE", "MESSAGE", "METACLASS", "METHOD", "METHOD-ID", "MODE", "MODULES", "MORE-LABELS", "MOVE", "MULTIPLE", "MULTIPLY", "NATIVE", "NATIVE_BINARY", "NEGATIVE", "NEXT", "NO", "NOT", "NULL", "NULLS", "NUMBER", "NUMERIC", "NUMERIC-EDITED", "OBJECT", "OBJECT-COMPUTER", "OCCURS", "OF", "OFF", "OMITTED", "ON", "OPEN", "OPTIONAL", "OR", "ORDER", "ORGANIZATION", "OTHER", "OUTPUT", "OVERFLOW", "OVERRIDE", "PACKED-DECIMAL", "PADDING", "PAGE", "PAGE-COUNTER", "PASSWORD", "PERFORM", "PF", "PH", "PIC", "PICTURE", "PLUS", "POINTER", "POSITION", "POSITIVE", "PRINTING", "PROCEDURE", "PROCEDURE-POINTER", "PROCEDURES", "PROCEED", "PROCESSING", "PROGRAM", "PROGRAM-ID", "PURGE", "QUEUE", "QUOTE", "QUOTES", "RANDOM", "RD", "READ", "READY", "RECEIVE", "RECORD", "RECORDING", "RECORDS", "RECURSIVE", "REDEFINES", "REEL", "REFERENCE", "REFERENCES", "RELATIVE", "RELEASE", "RELOAD", "REMAINDER", "REMOVAL", "RENAMES", "REPLACE", "REPLACING", "REPORT", "REPORTING", "REPORTS", "REPOSITORY", "RERUN", "RESERVE", "RESET", "RETURN", "RETURN-CODE", "RETURNING", "REVERSED", "REWIND", "REWRITE", "RF", "RH", "RIGHT", "ROUNDED", "RUN", "SAME", "SD", "SEARCH", "SECTION", "SECURITY", "SEGMENT", "SEGMENT-LIMIT", "SELECT", "SELF", "SEND", "SENTENCE", "SEPARATE", "SEQUENCE", "SEQUENTIAL", "SERVICE", "SET", "SHIFT-IN", "SHIFT-OUT", "SIGN", "SIZE", "SKIP1", "SKIP2", "SKIP3", "SORT", "SORT-CONTROL", "SORT-CORE-SIZE", "SORT-FILE-SIZE", "SORT-MERGE", "SORT-MESSAGE", "SORT-MODE-SIZE", "SORT-RETURN", "SOURCE", "SOURCE-COMPUTER", "SPACE", "SPACES", "SPECIAL-NAMES", "STANDARD", "STANDARD-1", "STANDARD-2", "START", "STATUS", "STOP", "STRING", "SUB-QUEUE-1", "SUB-QUEUE-2", "SUB-QUEUE-3", "SUBTRACT", "SUM", "SUPER", "SUPPRESS", "SYMBOLIC", "SYNC", "SYNCHRONIZED", "TABLE", "TALLY", "TALLYING", "TAPE", "TERMINAL", "TERMINATE", "TEST", "TEXT", "THAN", "THEN", "THROUGH", "THRU", "TIME", "TIMES", "TITLE", "TO", "TOP", "TRACE", "TRAILING", "TRUE", "TYPE", "UNIT", "UNSTRING", "UNTIL", "UP", "UPON", "USAGE", "USE", "USING", "VALUE", "VALUES", "VARYING", "WHEN", "WHEN-COMPILED", "WITH", "WORDS", "WORKING-STORAGE", "WRITE", "WRITE-ONLY", "ZERO", "ZEROES", "ZEROS" };
/*     */   static final String COBOL_CM_PATH = "cobolCM";
/*  20 */   static final String[] CONDITIONAL_KEYWORDS = new String[] { "IF", "ELSE", "ELSE-IF", "END-IF", "WHEN", "PERFORM", "GOTO", "SECTION", "CALL" };
/*     */ 
/*     */   
/*     */   static String[] fileNamesWithoutExt;
/*     */   
/*     */   static JSONObject lines;
/*     */   
/*     */   static JSONObject indexes;
/*     */   
/*     */   static final String outDir = "web\\assets\\";
/*     */   
/*     */   static HashMap<String, Integer> sectionStartAt;
/*     */   
/*     */   static HashMap<String, ArrayList<String>> sectionCalls;
/*     */   
/*     */   static HashMap<String, Integer> callStartAt;
/*     */ 
/*     */   
/*     */   public static void main2(String[] args) throws Exception {
/*  39 */     File f = new File("cobolCM");
/*  40 */     if (!f.exists()) {
/*  41 */       throw new Exception("Cobol File Path does not exists");
/*     */     }
/*     */     
/*  44 */     if (!f.isDirectory()) {
/*  45 */       throw new Exception("Cobol File Path is not a directory");
/*     */     }
/*     */     
/*  48 */     File[] files = f.listFiles();
/*  49 */     HashMap<String, ArrayList<String>> calls = new HashMap<>();
/*  50 */     HashMap<String, ArrayList<String>> calledby = new HashMap<>();
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile1;
/*  54 */     for (i = (arrayOfFile1 = files).length, b = 0; b < i; ) { File file = arrayOfFile1[b];
/*  55 */       if (file.exists() && !file.isDirectory()) {
/*  56 */         String file_name = file.getName().substring(0, file.getName().length() - 4);
/*  57 */         calls.put(file_name, new ArrayList<>());
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/*  62 */     fileNamesWithoutExt = (String[])calls.keySet().toArray((Object[])new String[0]);
/*     */     
/*  64 */     File[] files2 = { new File("C:\\SPL\\CCB240_EADEV\\cobol\\source\\cm\\CMPCACPR.cbl") };
/*     */     
/*     */     File[] arrayOfFile2;
/*  67 */     for (int j = (arrayOfFile2 = files).length; i < j; ) { File f2 = arrayOfFile2[i];
/*  68 */       if (f2.exists() && !f2.isDirectory()) {
/*  69 */         String file_name = f2.getName().substring(0, f2.getName().length() - 4);
/*  70 */         System.out.print(file_name);
/*  71 */         analyze(f2);
/*  72 */         JSONArray result = new JSONArray();
/*  73 */         result.put(lines.get("lines"));
/*  74 */         result.put(indexes.get("indexes"));
/*  75 */         result.put(new JSONObject(sectionCalls));
/*  76 */         result.put(new JSONObject(callStartAt));
/*  77 */         File outFile = new File("web\\assets\\" + file_name + ".json");
/*  78 */         FileWriter fw = new FileWriter(outFile);
/*  79 */         PrintWriter pw = new PrintWriter(fw);
/*  80 */         pw.write(result.toString());
/*  81 */         pw.close();
/*  82 */         fw.close();
/*  83 */         System.out.println(" done!!");
/*     */       } 
/*     */       i++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private static void analyze(File f2) throws Exception {
/*  91 */     lines = new JSONObject();
/*  92 */     indexes = new JSONObject();
/*     */     
/*  94 */     JSONArray myArray = new JSONArray();
/*  95 */     lines.put("lines", myArray);
/*     */     
/*  97 */     JSONArray myArray2 = new JSONArray();
/*  98 */     indexes.put("indexes", myArray2);
/*     */ 
/*     */     
/* 101 */     sectionStartAt = new HashMap<>();
/* 102 */     sectionCalls = new HashMap<>();
/* 103 */     callStartAt = new HashMap<>();
/*     */ 
/*     */     
/* 106 */     if (f2.exists() && !f2.isDirectory()) {
/* 107 */       String cur_file_name = f2.getName().substring(0, f2.getName().length() - 4);
/* 108 */       FileReader fr = new FileReader(f2);
/* 109 */       BufferedReader br = new BufferedReader(fr);
/* 110 */       int line_number = 1;
/* 111 */       String line = null;
/* 112 */       String currentSection = null;
/* 113 */       String firstSection = null;
/*     */       
/* 115 */       while ((line = br.readLine()) != null) {
/*     */ 
/*     */         
/* 118 */         String orgnial_line = line;
/*     */ 
/*     */         
/* 121 */         JSONObject l = new JSONObject();
/* 122 */         boolean isComment = false;
/*     */ 
/*     */         
/* 125 */         l.put("lno", line_number);
/*     */ 
/*     */         
/* 128 */         if (line.length() > 6 && line.charAt(6) == '*') {
/* 129 */           isComment = true;
/*     */         }
/*     */ 
/*     */         
/* 133 */         if (line != null && line.length() > 0 && line.charAt(0) == '$') {
/* 134 */           isComment = false;
/* 135 */           l.put("iss", true);
/*     */         } 
/*     */ 
/*     */         
/* 139 */         JSONArray kws = new JSONArray();
/*     */         
/* 141 */         if (!isComment) {
/* 142 */           byte b1; int j; String[] arrayOfString1; for (j = (arrayOfString1 = COBOL_KEYWORDS).length, b1 = 0; b1 < j; ) { String kw = arrayOfString1[b1];
/* 143 */             if (line.contains(" " + kw + " ")) {
/* 144 */               kws.put(kw);
/* 145 */               line = line.replace(" " + kw + " ", " <span class=\"keyword\">" + kw + "</span> ");
/* 146 */             } else if (line.contains(" " + kw + ".")) {
/* 147 */               kws.put(kw);
/* 148 */               line = line.replace(" " + kw + ".", " <span class=\"keyword\">" + kw + "</span>.");
/*     */             } 
/*     */             b1++; }
/*     */         
/*     */         } 
/* 153 */         JSONArray cmProgs = new JSONArray(); byte b; int i;
/*     */         String[] arrayOfString;
/* 155 */         for (i = (arrayOfString = fileNamesWithoutExt).length, b = 0; b < i; ) { String pgName = arrayOfString[b];
/* 156 */           if (line.contains(pgName)) {
/* 157 */             cmProgs.put(pgName);
/* 158 */             line = line.replace(pgName, "<span class=\"program\">" + pgName + "</span>");
/*     */           } 
/*     */ 
/*     */           
/*     */           b++; }
/*     */ 
/*     */         
/* 165 */         JSONObject l2 = new JSONObject();
/*     */         
/* 167 */         if (!isComment) {
/* 168 */           if (orgnial_line.contains(" SECTION.")) {
/* 169 */             String section_name = orgnial_line.trim().split(" ")[0];
/* 170 */             l2.put("sn", section_name);
/* 171 */             l2.put("lno", line_number);
/* 172 */             if (currentSection == null) {
/* 173 */               firstSection = section_name;
/*     */             }
/* 175 */             currentSection = section_name;
/* 176 */             sectionStartAt.put(currentSection, Integer.valueOf(line_number));
/* 177 */             line = line.replace(section_name, "<span class=\"sectionName\">" + section_name + "</span>");
/* 178 */             myArray2.put(l2);
/* 179 */           } else if (orgnial_line.contains("PERFORM ")) {
/*     */             try {
/* 181 */               String performing_sec = orgnial_line.trim().split("PERFORM ")[1].trim().split(" ")[0];
/*     */               
/* 183 */               if (!performing_sec.startsWith("VARYING") || performing_sec.startsWith("UNTIL")) {
/* 184 */                 if (sectionCalls.get(currentSection) == null) {
/* 185 */                   sectionCalls.put(currentSection, new ArrayList<>());
/*     */                 }
/*     */                 
/* 188 */                 line = line.replace(performing_sec, "<span class=\"sectionName\">" + performing_sec + "</span>");
/* 189 */                 ((ArrayList<String>)sectionCalls.get(currentSection)).add(performing_sec);
/* 190 */                 callStartAt.put(String.valueOf(currentSection) + performing_sec, Integer.valueOf(line_number));
/*     */               } 
/* 192 */             } catch (Exception e) {
/* 193 */               System.out.println(" Error!!  PERFORM on Line : " + orgnial_line);
/*     */             } 
/* 195 */           } else if (orgnial_line.contains("CALL ")) {
/* 196 */             String performing_sec = null;
/* 197 */             if (orgnial_line.contains("'")) {
/* 198 */               performing_sec = orgnial_line.trim().split("'")[1];
/*     */             } else {
/* 200 */               performing_sec = orgnial_line.trim().split("CALL ")[0];
/*     */             } 
/* 202 */             if (sectionCalls.get(currentSection) == null) {
/* 203 */               sectionCalls.put(currentSection, new ArrayList<>());
/*     */             }
/* 205 */             line = line.replace(performing_sec, "<span class=\"sectionName\">" + performing_sec + "</span>");
/* 206 */             ((ArrayList<String>)sectionCalls.get(currentSection)).add(performing_sec);
/* 207 */             callStartAt.put(String.valueOf(currentSection) + performing_sec, Integer.valueOf(line_number));
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 212 */         if (!isComment) {
/* 213 */           l.put("isC", true); String[] arrayOfString1;
/* 214 */           for (int j = (arrayOfString1 = CONDITIONAL_KEYWORDS).length; i < j; ) { String s = arrayOfString1[i];
/* 215 */             if (orgnial_line.contains(" " + s + " ") || orgnial_line.contains(" " + s + ".")) {
/* 216 */               l.put("isC", false);
/*     */             }
/*     */             i++; }
/*     */         
/*     */         } else {
/* 221 */           l.put("isC", false);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 226 */         if (isComment)
/* 227 */           l.put("isc", isComment); 
/* 228 */         l.put("l", line);
/*     */ 
/*     */         
/* 231 */         myArray.put(l);
/*     */ 
/*     */         
/* 234 */         line_number++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\james\Downloads\cobolWebModule\Release\COBOL-WEB-MODULE.jar!\com\main\CobolAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */