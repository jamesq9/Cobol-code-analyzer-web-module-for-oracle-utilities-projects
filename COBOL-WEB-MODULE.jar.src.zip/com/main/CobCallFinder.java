/*     */ package com.main;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CobCallFinder
/*     */ {
/*     */   static final String COBOL_CM_PATH = "cobolCM";
/*     */   static final String SEPARATOR = " -> ";
/*     */   static final String outDir = "web\\assets\\";
/*     */   
/*     */   public static void main2(String[] args) throws Exception {
/*  24 */     File f = new File("cobolCM");
/*  25 */     if (!f.exists()) {
/*  26 */       throw new Exception("Cobol File Path does not exists");
/*     */     }
/*     */     
/*  29 */     if (!f.isDirectory()) {
/*  30 */       throw new Exception("Cobol File Path is not a directory");
/*     */     }
/*     */     
/*  33 */     File[] files = f.listFiles();
/*  34 */     HashMap<String, ArrayList<String>> calls = new HashMap<>();
/*  35 */     HashMap<String, ArrayList<String>> calledby = new HashMap<>();
/*     */     byte b;
/*     */     int i;
/*     */     File[] arrayOfFile1;
/*  39 */     for (i = (arrayOfFile1 = files).length, b = 0; b < i; ) { File file = arrayOfFile1[b];
/*  40 */       if (file.exists() && !file.isDirectory()) {
/*  41 */         String file_name = file.getName().substring(0, file.getName().length() - 4);
/*  42 */         calls.put(file_name, new ArrayList<>());
/*  43 */         calledby.put(file_name, new ArrayList<>());
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/*  48 */     String[] fileNamesWithoutExt = (String[])calls.keySet().toArray((Object[])new String[0]);
/*     */     
/*     */     File[] arrayOfFile2;
/*  51 */     for (int j = (arrayOfFile2 = files).length; i < j; ) { File file = arrayOfFile2[i];
/*  52 */       if (file.exists() && !file.isDirectory()) {
/*  53 */         String cur_file_name = file.getName().substring(0, file.getName().length() - 4);
/*  54 */         FileReader fr = new FileReader(file);
/*  55 */         BufferedReader br = new BufferedReader(fr);
/*  56 */         String line = null;
/*  57 */         while ((line = br.readLine()) != null) {
/*  58 */           if (line.length() <= 6 || line.charAt(6) == '*')
/*  59 */             continue;  byte b1; int k; String[] arrayOfString; for (k = (arrayOfString = fileNamesWithoutExt).length, b1 = 0; b1 < k; ) { String pattern = arrayOfString[b1];
/*  60 */             if (line.contains(pattern) && !pattern.equals(cur_file_name)) {
/*  61 */               if (!((ArrayList)calls.get(cur_file_name)).contains(pattern)) {
/*  62 */                 ((ArrayList<String>)calls.get(cur_file_name)).add(pattern);
/*     */               }
/*  64 */               if (!((ArrayList)calledby.get(pattern)).contains(cur_file_name)) {
/*  65 */                 ((ArrayList<String>)calledby.get(pattern)).add(cur_file_name);
/*     */               }
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             b1++; }
/*     */         
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       i++; }
/*     */ 
/*     */ 
/*     */     
/*  81 */     JSONObject main = new JSONObject();
/*  82 */     main.put("fileNames", new JSONArray(fileNamesWithoutExt));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     main.put("calls", new JSONObject(calls));
/* 151 */     main.put("calledBy", new JSONObject(calledby));
/* 152 */     File outFile = new File("web\\assets\\mainData.json");
/* 153 */     FileWriter fw = new FileWriter(outFile);
/* 154 */     PrintWriter pw = new PrintWriter(fw);
/* 155 */     pw.write(main.toString());
/* 156 */     pw.close();
/* 157 */     fw.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\james\Downloads\cobolWebModule\Release\COBOL-WEB-MODULE.jar!\com\main\CobCallFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */