/*    */ package com.main;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.jibble.simplewebserver.SimpleWebServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static void main(String[] args) throws Exception {
/* 12 */     System.out.println("\nArguments that you can pass to this program.");
/* 13 */     System.out.println("\t 1. Generate metaData - True , Default Value: false");
/* 14 */     System.out.println("\t 2. PORT number , Default Value: 8082");
/* 15 */     System.out.println("e.g: java -jar CobolWebModule.jar true 8080");
/*    */ 
/*    */     
/* 18 */     int default_port = 8082;
/* 19 */     if (args.length >= 2) {
/* 20 */       default_port = Integer.parseInt(args[1]);
/*    */     }
/*    */     
/* 23 */     if (args.length >= 1 && 
/* 24 */       args[0].equalsIgnoreCase("true")) {
/* 25 */       CobCallFinder.main2(new String[] { "" });
/* 26 */       CobolAnalyzer.main2(new String[] { "" });
/*    */     } 
/*    */ 
/*    */     
/* 30 */     SimpleWebServer server = new SimpleWebServer(new File("./web/"), default_port);
/* 31 */     System.out.println("\nCobol ADDC Web Module started visit http://localhost:" + default_port + "/");
/*    */   }
/*    */ }


/* Location:              C:\Users\james\Downloads\cobolWebModule\Release\COBOL-WEB-MODULE.jar!\com\main\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */